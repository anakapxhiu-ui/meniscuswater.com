# Meniscus Backend

## Quick start

```bash
# Prerequisites: Postgres 14+ with PostGIS, Python 3.11+

# 1. Create database
createdb meniscus
psql meniscus -f schema.sql

# 2. Set up environment
cp .env.example .env
# Fill in DATABASE_URL, MAPBOX_TOKEN, ANTHROPIC_API_KEY

# 3. Install deps
pip install -r requirements.txt

# 4. Seed the contaminants reference table
python ingest/seed_contaminants.py

# 5. Load real EPA data (takes 30-60 min total)
python ingest/sdwis_loader.py --state TX   # start with one state
python ingest/ucmr5_loader.py
python ingest/superfund_loader.py

# 6. Run API
uvicorn api:app --reload --port 8000
```

## Architecture

```
request → geocode → cache check → resolve utility → pull results
                                                    → pull sites
                                                    → score (deterministic)
                                                    → narrative (LLM)
                                                    → match products
                                                    → cache + return
```

## Test

```bash
curl -X POST http://localhost:8000/api/lookup \
  -H "Content-Type: application/json" \
  -d '{"address": "7912 Running Water Dr, Austin, TX 78747"}'
```

## What's NOT in the MVP

- State-level data sources (add per state as you expand)
- Service area polygon matching (falls back to state-level; upgrade when EPA boundary dataset is loaded)
- Installer marketplace queries (schema is ready; endpoints come in Phase 2)
- User authentication (use Supabase Auth or Clerk; not in this code)
- Payment / affiliate click tracking (use Rewardful, Impact, or roll your own)

## Production hardening checklist

- [ ] Toxicologist review of every entry in `data/contaminants.json`
- [ ] Add Sentry or Datadog for error tracking
- [ ] Rate limit `/api/lookup` (Redis + FastAPI-limiter)
- [ ] Add API auth for anything beyond read-only lookup
- [ ] Move `CORS` from `["*"]` to explicit origins
- [ ] Back up `contaminant_results` nightly (your moat is in here)
